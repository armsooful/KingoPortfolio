# 기술 레퍼런스 (Reference)

API 명세, 시스템 아키텍처, 기술 상세 문서 모음

---

## 📖 문서 목록

### [API_DOCUMENTATION.md](API_DOCUMENTATION.md)
**전체 API 엔드포인트 명세**

- 68개 API 엔드포인트 상세
- 요청/응답 스키마
- 인증 방식
- 에러 코드
- 사용 예제

**대상**: 백엔드/프론트엔드 개발자
**참조 빈도**: ⭐⭐⭐⭐⭐

#### 주요 섹션
- 인증 API (8개)
- 진단 API (6개)
- 관리자 API (20개)
- 금융 분석 API (12개)
- 공개 API (5개)

---

### [RBAC_IMPLEMENTATION.md](RBAC_IMPLEMENTATION.md)
**역할 기반 접근 제어**

- RBAC 개념 및 구조
- 3가지 역할 (user, premium, admin)
- 권한 데코레이터 구현
- 역할별 접근 권한
- 마이그레이션 가이드

**대상**: 백엔드 개발자
**참조 빈도**: ⭐⭐⭐⭐

#### 역할 구조
```
admin (최고 권한)
  ├─ 모든 엔드포인트 접근
  ├─ 사용자 관리
  └─ 데이터 수집 관리

premium (프리미엄)
  ├─ user 권한
  ├─ 고급 분석 기능
  └─ 무제한 진단

user (일반 사용자)
  ├─ 프로필 관리
  ├─ 기본 진단 (제한적)
  └─ 데이터 내보내기
```

---

### [ERROR_HANDLING.md](ERROR_HANDLING.md)
**에러 핸들링 시스템**

- 표준 에러 코드
- 커스텀 예외 클래스
- 에러 핸들러 구현
- 에러 응답 형식
- 클라이언트 에러 처리

**대상**: 백엔드/프론트엔드 개발자
**참조 빈도**: ⭐⭐⭐

#### 주요 에러 코드
- 400: Bad Request (잘못된 요청)
- 401: Unauthorized (인증 실패)
- 403: Forbidden (권한 없음)
- 404: Not Found (리소스 없음)
- 409: Conflict (중복 데이터)
- 429: Too Many Requests (Rate Limit)
- 500: Internal Server Error (서버 오류)

---

## 🎯 사용 시나리오

### API 통합 (프론트엔드)
```
1. API_DOCUMENTATION.md - 필요한 엔드포인트 찾기
2. 요청 파라미터 및 헤더 확인
3. 응답 형식 확인
4. ERROR_HANDLING.md - 에러 처리 구현
5. RBAC_IMPLEMENTATION.md - 권한 확인
```

### 새 엔드포인트 구현 (백엔드)
```
1. API_DOCUMENTATION.md - 기존 패턴 참조
2. RBAC_IMPLEMENTATION.md - 권한 데코레이터 추가
3. ERROR_HANDLING.md - 적절한 예외 사용
4. 구현 후 API_DOCUMENTATION.md 업데이트
```

### 권한 시스템 이해
```
1. RBAC_IMPLEMENTATION.md - 전체 구조 파악
2. API_DOCUMENTATION.md - 엔드포인트별 필요 권한 확인
3. guides/PROFILE.md - 사용자 관리 방법
```

### 에러 디버깅
```
1. ERROR_HANDLING.md - 에러 코드 의미 확인
2. API_DOCUMENTATION.md - 엔드포인트별 에러 케이스
3. 로그 확인
4. 가이드 문서의 "문제 해결" 섹션
```

---

## 📋 빠른 참조

### API 엔드포인트 검색
```bash
# 특정 엔드포인트 찾기
grep -n "/auth/profile" API_DOCUMENTATION.md

# 인증 관련 엔드포인트
grep -A 5 "POST /auth" API_DOCUMENTATION.md

# 관리자 전용 엔드포인트
grep -B 2 "admin" API_DOCUMENTATION.md
```

### 권한 확인
```bash
# 역할별 권한
grep -A 10 "user:" RBAC_IMPLEMENTATION.md
grep -A 10 "premium:" RBAC_IMPLEMENTATION.md
grep -A 10 "admin:" RBAC_IMPLEMENTATION.md

# 특정 엔드포인트 권한
grep "/diagnosis" RBAC_IMPLEMENTATION.md
```

### 에러 코드 찾기
```bash
# 특정 에러 코드
grep -A 5 "401" ERROR_HANDLING.md

# 에러 메시지 검색
grep "중복" ERROR_HANDLING.md
```

---

## 🔍 자주 찾는 정보

### 인증 헤더
```
Authorization: Bearer <jwt_token>
```

### 공통 응답 형식
```json
{
  "status": "success",
  "data": { ... },
  "message": "Success message"
}
```

### 에러 응답 형식
```json
{
  "detail": "Error message",
  "status_code": 400,
  "error_type": "BadRequest"
}
```

### Rate Limit 헤더
```
X-RateLimit-Limit: 10
X-RateLimit-Remaining: 7
X-RateLimit-Reset: 1640995200
```

---

## 📊 문서 통계

| 문서 | 라인 수 | 용량 | API/개념 수 |
|------|---------|------|-------------|
| API_DOCUMENTATION.md | 1,200줄 | 11KB | 68개 API |
| RBAC_IMPLEMENTATION.md | 280줄 | 5.9KB | 3개 역할 |
| ERROR_HANDLING.md | 450줄 | 11KB | 20+ 에러 타입 |

**총 레퍼런스 항목**: 90+

---

## 🔄 레퍼런스 업데이트 규칙

### API_DOCUMENTATION.md 업데이트 (필수)
- ✅ 새 엔드포인트 추가
- ✅ 엔드포인트 변경 (URL, 파라미터, 응답)
- ✅ 엔드포인트 삭제
- ✅ 인증 방식 변경
- ✅ 에러 코드 추가/변경

### RBAC_IMPLEMENTATION.md 업데이트
- ✅ 새 역할 추가
- ✅ 역할 권한 변경
- ✅ 권한 데코레이터 변경
- ✅ 마이그레이션 필요 시

### ERROR_HANDLING.md 업데이트
- ✅ 새 에러 타입 추가
- ✅ 에러 코드 변경
- ✅ 에러 응답 형식 변경
- ✅ 에러 핸들러 로직 변경

---

## ⚠️ 중요 주의사항

### API 변경 시
1. **하위 호환성 유지** - 기존 클라이언트 고려
2. **버전 관리** - 큰 변경 시 API 버전 올리기
3. **문서 동기화** - API 코드와 문서 일치 필수
4. **변경 공지** - CHANGELOG.md 및 클라이언트 팀에 공지

### 권한 변경 시
1. **데이터베이스 마이그레이션** - 기존 사용자 역할 확인
2. **테스트** - 권한별 접근 테스트 필수
3. **문서화** - RBAC_IMPLEMENTATION.md 업데이트

### 에러 처리 변경 시
1. **클라이언트 영향 확인** - 기존 에러 처리 로직
2. **에러 메시지** - 사용자 친화적 메시지
3. **로깅** - 디버깅을 위한 상세 로그

---

## 🛠️ 개발 도구

### Swagger UI
```
http://localhost:8000/docs
```
- 대화형 API 문서
- API 테스트 가능
- 자동 생성 (FastAPI)

### ReDoc
```
http://localhost:8000/redoc
```
- 읽기 전용 API 문서
- 깔끔한 UI
- 자동 생성 (FastAPI)

### Postman Collection
```
docs/reference/postman/
```
- API 테스트 컬렉션
- 환경 변수 설정
- 예제 요청

---

## 📞 레퍼런스 관련 문의

### API 관련
- Swagger/ReDoc 자동 생성 문서 먼저 확인
- API_DOCUMENTATION.md 참조
- GitHub Issues에 질문 등록

### 권한 관련
- RBAC_IMPLEMENTATION.md FAQ 섹션 확인
- Backend Team에 문의

### 에러 처리
- ERROR_HANDLING.md 문제 해결 섹션
- 로그 확인 후 이슈 등록

---

## 🔗 관련 문서

### 가이드 문서
- [PROFILE.md](../guides/PROFILE.md) - 프로필 API 사용법
- [EXPORT.md](../guides/EXPORT.md) - 내보내기 API 사용법
- [RATE_LIMITING.md](../guides/RATE_LIMITING.md) - Rate Limit 처리

### 개발 문서
- [TESTING.md](../development/TESTING.md) - API 테스트
- [CHANGELOG.md](../development/CHANGELOG.md) - API 변경 이력

---

**마지막 업데이트**: 2025-12-29
**총 레퍼런스 문서**: 3개
**총 API 엔드포인트**: 68개
