# 포트폴리오 추천 시스템 데이터 요구사항

**작성일**: 2025-12-29
**버전**: 1.0.0
**상태**: 데이터 수집 필요

---

## 📋 목차

1. [현재 데이터 현황](#현재-데이터-현황)
2. [부족한 데이터 분석](#부족한-데이터-분석)
3. [우선순위별 수집 계획](#우선순위별-수집-계획)
4. [데이터 소스](#데이터-소스)
5. [구현 계획](#구현-계획)

---

## 현재 데이터 현황

### 데이터베이스 통계 (2025-12-29 기준)

```
✅ 주식 (stocks): 34개
✅ ETF (etfs): 29개
❌ 채권 (bonds): 0개
❌ 예금상품 (deposit_products): 0개
```

### 주식 데이터 품질 분석

**샘플 데이터 확인 결과:**

| 컬럼 | 상태 | 예시 값 | 비고 |
|------|------|---------|------|
| ticker | ✅ 있음 | 005930 | 종목코드 |
| name | ✅ 있음 | 삼성전자 | 종목명 |
| sector | ✅ 있음 | 전자/반도체 | 섹터 |
| current_price | ✅ 있음 | (계산값) | 있으나 정확도 확인 필요 |
| market_cap | ❌ NULL | - | 시가총액 없음 |
| **pe_ratio** | ❌ **NULL** | - | **PER 없음 (중요)** |
| **pb_ratio** | ❌ **NULL** | - | **PBR 없음 (중요)** |
| **dividend_yield** | ❌ **NULL** | - | **배당률 없음 (중요)** |
| **ytd_return** | ❌ **NULL** | - | **YTD 수익률 없음** |
| one_year_return | ✅ 있음 | 119.92% | 1년 수익률 |
| risk_level | ✅ 있음 | medium | 리스크 레벨 |
| investment_type | ⚠️ 확인필요 | - | 투자 성향 매핑 |

**심각도 평가**: 🔴 **높음**
- 포트폴리오 엔진이 의존하는 핵심 지표(PER, PBR, 배당률)가 모두 NULL
- 밸류에이션 점수 30점 중 0점 처리됨
- 배당 점수 20-30점 중 0점 처리됨

---

## 부족한 데이터 분석

### 1. 주식 (Stock) 데이터

#### 1.1 현재 NULL인 중요 데이터

##### 🔴 긴급 (포트폴리오 엔진 핵심)

| 항목 | 영문명 | 중요도 | 현재상태 | 수집방법 |
|------|--------|--------|----------|----------|
| **PER** | Price-to-Earnings Ratio | ⭐⭐⭐⭐⭐ | ❌ NULL | KRX, 네이버금융 |
| **PBR** | Price-to-Book Ratio | ⭐⭐⭐⭐⭐ | ❌ NULL | KRX, 네이버금융 |
| **배당수익률** | Dividend Yield | ⭐⭐⭐⭐⭐ | ❌ NULL | KRX, DART |
| **YTD 수익률** | Year-to-Date Return | ⭐⭐⭐⭐ | ❌ NULL | pykrx 계산 |
| **시가총액** | Market Capitalization | ⭐⭐⭐⭐ | ❌ NULL | KRX |

**영향도**:
```python
# 현재 점수 계산 (최대 100점)
성과 점수: 20점 (1년 수익률만 사용)
밸류에이션: 0점 (PER, PBR NULL)
배당 점수: 0점 (배당률 NULL)
리스크 조정: 10점 (있음)
------------------------
총점: 30점/100점 (70점 손실)
```

#### 1.2 추가 필요 재무 지표

##### 🟡 중요 (포트폴리오 품질 향상)

**수익성 지표**:
- `roe` - ROE (자기자본이익률): 수익성의 핵심 지표
- `roa` - ROA (총자산이익률): 자산 활용 효율
- `operating_margin` - 영업이익률: 본업 수익성
- `net_margin` - 순이익률: 최종 수익성
- `eps` - EPS (주당순이익): 주가 평가 기준

**재무 안정성**:
- `debt_ratio` - 부채비율: 재무 건전성
- `debt_to_equity` - 부채/자본 비율: 레버리지
- `current_ratio` - 유동비율: 단기 지급능력
- `quick_ratio` - 당좌비율: 즉시 지급능력

**성장성 지표**:
- `revenue_growth` - 매출 증가율 (YoY)
- `earnings_growth` - 순이익 증가율 (YoY)
- `eps_growth` - EPS 성장률

**장기 성과**:
- `three_month_return` - 3개월 수익률
- `six_month_return` - 6개월 수익률
- `three_year_return` - 3년 수익률
- `five_year_return` - 5년 수익률
- `ten_year_return` - 10년 수익률

#### 1.3 고급 밸류에이션 지표

##### 🟢 선택 (차별화 요소)

**추가 밸류에이션**:
- `peg_ratio` - PEG 비율 (PER / 성장률): 성장 대비 가치
- `pcr_ratio` - PCR (가격/현금흐름): 현금 창출 능력
- `psr_ratio` - PSR (가격/매출): 매출 대비 가치
- `ev_to_ebitda` - EV/EBITDA: 기업가치 평가

**배당 고급 지표**:
- `dividend_per_share` - 주당 배당금 (DPS)
- `dividend_payout_ratio` - 배당성향 (%): 배당 지속가능성
- `dividend_growth_rate` - 배당 증가율 (3년)
- `consecutive_dividend_years` - 연속 배당 연수

#### 1.4 리스크 및 변동성 지표

##### 🟡 중요 (리스크 관리)

**변동성 측정**:
- `beta` - 베타: 시장 대비 민감도 (필수)
- `volatility` - 변동성 (표준편차, 20일)
- `historical_volatility` - 역사적 변동성 (1년)
- `max_drawdown` - 최대 낙폭 (%): 위험도 지표

**거래 유동성**:
- `avg_volume` - 일평균 거래량 (20일)
- `volume_ratio` - 거래량 비율
- `liquidity_score` - 유동성 점수 (0-100)

#### 1.5 퀀트/기술적 지표

##### 🟢 선택 (고급 전략)

**모멘텀 지표**:
- `rsi` - RSI (상대강도지수, 14일)
- `momentum_score` - 모멘텀 점수 (6개월)
- `price_momentum` - 가격 모멘텀 (52주)

**위험조정 수익률**:
- `sharpe_ratio` - 샤프 비율: 위험 대비 수익
- `sortino_ratio` - 소르티노 비율: 하방 위험 대비 수익
- `information_ratio` - 정보 비율: 벤치마크 대비 초과수익

**기술적 지표**:
- `ma_50` - 50일 이동평균
- `ma_200` - 200일 이동평균
- `price_to_ma_50` - 현재가/50일MA 비율
- `price_to_ma_200` - 현재가/200일MA 비율

### 2. ETF 데이터

#### 2.1 현재 데이터 상태

| 항목 | 상태 | 비고 |
|------|------|------|
| ticker, name | ✅ | 기본 정보 있음 |
| current_price | ✅ | 현재가 있음 |
| aum | ⚠️ | 운용자산 확인 필요 |
| expense_ratio | ⚠️ | 수수료율 확인 필요 |
| one_year_return | ⚠️ | 1년 수익률 확인 필요 |

#### 2.2 추가 필요 데이터

##### 🟡 중요

**ETF 특화 지표**:
- `nav` - 순자산가치 (Net Asset Value)
- `premium_discount` - 프리미엄/할인율 (%): 괴리율
- `tracking_error` - 추적오차: 벤치마크 추종도
- `tracking_difference` - 추적 차이

**포트폴리오 정보**:
- `holdings_count` - 보유 종목 수
- `top_10_holdings` - 상위 10개 종목 (JSON)
- `sector_allocation` - 섹터 배분 (JSON)
- `country_allocation` - 국가 배분 (JSON)
- `rebalancing_frequency` - 리밸런싱 주기

**성과 지표**:
- `three_month_return` - 3개월 수익률
- `three_year_return` - 3년 수익률
- `five_year_return` - 5년 수익률
- `inception_return` - 설정 이후 수익률

**기본 정보**:
- `inception_date` - 설정일/상장일
- `benchmark_index` - 기초지수
- `distribution_frequency` - 분배금 지급 주기
- `last_distribution` - 최근 분배금

### 3. 채권 (Bond) 데이터 - 완전 부재 ❌

#### 3.1 필요한 채권 종류

##### 🔴 긴급 (포트폴리오 필수 자산)

**국채 (Government Bonds)**:
```
우선순위 1: 기준 금리 참조용
- 3년 국고채 (중단기)
- 5년 국고채 (중기)
- 10년 국고채 (장기)
- 20년 국고채 (초장기)

수집 항목:
- 채권명, 종목코드
- 표면금리, 만기일
- 현재 수익률 (YTM)
- 최소 투자금액
```

**우량 회사채 (Investment Grade Corporate Bonds)**:
```
우선순위 2: 안정적 수익 추구
- AAA 회사채 (최우량)
- AA 회사채 (우량)
- A 회사채 (양호)

대상 기업:
- 삼성전자, SK하이닉스 (전자)
- 현대자동차, 기아 (자동차)
- KB금융, 신한금융 (금융)
```

**특수채**:
```
우선순위 3: 다각화
- 금융채 (은행, 증권사)
- 지방채 (서울시, 경기도)
- 특수채 (한국전력, 도로공사)
```

##### 🟡 중요 (고수익 추구)

**하이일드 채권 (High Yield Bonds)**:
```
투자등급 미만 (BB 이하)
- BBB 회사채
- BB 이하 고수익 채권

리스크: 높음
수익률: 높음 (국채 +3~5%p)
```

#### 3.2 채권 데이터 스키마

```python
class Bond:
    # 기본 정보
    name: str                    # 채권명
    isin_code: str              # ISIN 코드
    ticker: str                 # 종목코드
    bond_type: str              # government, corporate, special
    issuer: str                 # 발행자

    # 금리 정보
    coupon_rate: float          # 표면금리 (%)
    ytm: float                  # 만기수익률 (Yield to Maturity, %)
    current_yield: float        # 현재수익률 (%)

    # 만기 정보
    issue_date: date            # 발행일
    maturity_date: date         # 만기일
    maturity_years: int         # 잔존만기 (년)

    # 신용 정보
    credit_rating: str          # AAA, AA+, AA, AA-, A+, A, A-, BBB+...
    rating_agency: str          # 평가기관 (한국신용평가, NICE신용평가)

    # 가격 정보
    face_value: int             # 액면가 (보통 10,000원)
    current_price: float        # 현재가 (원)
    minimum_investment: int     # 최소 투자금액

    # 듀레이션 (금리 민감도)
    duration: float             # 듀레이션 (년)
    modified_duration: float    # 수정 듀레이션
    convexity: float           # 컨벡서티

    # 분류
    risk_level: str             # low, medium, high
    investment_type: str        # conservative, moderate, aggressive
```

### 4. 예금상품 (Deposit) 데이터 - 완전 부재 ❌

#### 4.1 필요한 예금 종류

##### 🔴 긴급 (유동성 자산 필수)

**정기예금 (Time Deposit)**:
```
주요 은행 (시중은행 5개 이상):
- KB국민은행
- 신한은행
- 하나은행
- 우리은행
- NH농협은행

기간별:
- 1개월 (초단기)
- 3개월 (단기)
- 6개월 (중단기)
- 1년 (중기) ⭐ 가장 많이 사용
- 2년 (장기)
- 3년 (장기)

금리 구분:
- 기본금리
- 우대금리 (최대)
```

**CMA / MMF**:
```
우선순위 1: 유동성 최고
- 종합자산관리계좌 (CMA)
- 머니마켓펀드 (MMF)

특징:
- 입출금 자유
- 일정 수익률 (연 2-3%)
- 예금자보호 (CMA 일부)
```

##### 🟡 중요 (목돈 마련)

**적금 (Savings)**:
```
종류:
- 정기적금 (매월 정액)
- 자유적금 (자유 입금)

우대 조건:
- 급여이체, 카드사용, 공과금납부
- 청년, 군인, 주거래 고객
```

#### 4.2 예금 데이터 스키마

```python
class DepositProduct:
    # 기본 정보
    name: str                   # 상품명
    bank: str                   # 은행명
    product_type: str           # deposit, cma, savings
    product_code: str           # 상품코드

    # 금리 정보
    base_interest_rate: float   # 기본금리 (%)
    max_interest_rate: float    # 최고우대금리 (%)
    preferential_conditions: str # 우대조건 (JSON)

    # 기간 정보
    term_months: int            # 기간 (개월)
    available_terms: list       # 선택가능 기간 [1,3,6,12,24,36]

    # 금액 정보
    minimum_amount: int         # 최소 가입금액
    maximum_amount: int         # 최대 가입금액

    # 특징
    early_termination_rate: float    # 중도해지 금리 (%)
    deposit_protection: bool    # 예금자보호 여부
    compound_interest: bool     # 복리 여부

    # 가입 대상
    target_customer: str        # all, youth, senior, soldier
    age_limit: str             # 나이 제한
```

---

## 우선순위별 수집 계획

### Phase 1: 긴급 데이터 (1-2주) 🔴

**목표**: 포트폴리오 엔진이 정상 작동하도록 핵심 데이터 수집

#### 주식 데이터
- [ ] PER (Price-to-Earnings Ratio)
- [ ] PBR (Price-to-Book Ratio)
- [ ] 배당수익률 (Dividend Yield)
- [ ] YTD 수익률 (Year-to-Date Return)
- [ ] 시가총액 (Market Cap) 정확도 검증

**예상 효과**:
```
현재: 30점/100점 (70점 손실)
개선: 80점/100점 (정상 작동)
```

#### 채권 데이터
- [ ] 3년 국고채 (1개)
- [ ] 5년 국고채 (1개)
- [ ] 10년 국고채 (1개)
- [ ] AAA 회사채 (2-3개: 삼성, SK, 현대차)

#### 예금 데이터
- [ ] 주요 5개 은행 1년 정기예금
- [ ] CMA 1-2개 (증권사)

**데이터 소스**:
```python
- KRX API (PER, PBR, 시가총액)
- pykrx 라이브러리 (배당, 수익률)
- 한국은행 ECOS (국채 수익률)
- 금융감독원 금융상품 공시 (예금 금리)
```

### Phase 2: 중요 데이터 (3-4주) 🟡

**목표**: 포트폴리오 품질 향상 및 다각화

#### 주식 추가 지표
- [ ] ROE, ROA (수익성)
- [ ] 부채비율, 유동비율 (안정성)
- [ ] 매출/순이익 증가율 (성장성)
- [ ] 베타, 변동성 (리스크)

#### ETF 상세 정보
- [ ] 추적오차 (Tracking Error)
- [ ] 보유종목 수 및 상위 종목
- [ ] 섹터 배분

#### 채권 확대
- [ ] A등급 회사채 (5개)
- [ ] 금융채 (3개)
- [ ] BBB 회사채 (2개)

#### 예금 확대
- [ ] 3개월, 6개월 정기예금
- [ ] MMF 2-3개
- [ ] 정기적금 2-3개

### Phase 3: 고급 데이터 (5-8주) 🟢

**목표**: 차별화된 포트폴리오 전략

#### 고급 밸류에이션
- [ ] PEG, PCR, PSR 비율
- [ ] EV/EBITDA

#### 퀀트 지표
- [ ] 샤프 비율 (Sharpe Ratio)
- [ ] RSI, 모멘텀 점수
- [ ] 이동평균선 (MA 50, MA 200)

#### 배당 고급 분석
- [ ] 배당성향, 배당증가율
- [ ] 연속 배당 연수

---

## 데이터 소스

### 한국 주식 데이터

#### 1. pykrx (무료, 현재 사용 중)
```python
from pykrx import stock

# 장점
✅ 무료
✅ 한국 주식 특화
✅ 설치 간편

# 수집 가능 데이터
- 주가 (시가, 고가, 저가, 종가)
- 거래량, 거래대금
- 시가총액
- PER, PBR, 배당수익률 ⭐
- 외국인/기관 보유량

# 사용 예제
ticker = "005930"  # 삼성전자
df = stock.get_market_fundamental(date, ticker)
# -> PER, PBR, 배당수익률 추출
```

#### 2. KRX 정보데이터시스템 (무료)
```python
웹사이트: http://data.krx.co.kr

# 수집 가능 데이터
- 종목 기본정보
- 재무제표 (분기/연간)
- PER, PBR, EPS
- 배당 정보
- 시가총액

# API: 공개 API 없음, 웹 스크래핑 필요
```

#### 3. DART (전자공시시스템) - 무료
```python
웹사이트: https://opendart.fss.or.kr

# 장점
✅ 무료 (API Key 발급)
✅ 공식 재무제표
✅ 상세한 재무 정보

# 수집 가능 데이터
- 사업보고서
- 분기/반기/연간 보고서
- 재무제표 (상세)
- 배당 정보
- 감사의견

# 사용 예제
import dart_fss as dart

dart.set_api_key("YOUR_API_KEY")
corp = dart.get_corp("삼성전자")
fs = corp.get_financial_statement()
```

#### 4. 네이버 금융 (무료, 스크래핑)
```python
URL: https://finance.naver.com

# 수집 가능 데이터
- 실시간 시세
- PER, PBR, 배당률
- 재무비율
- 투자의견 (컨센서스)

# 주의: API 없음, 크롤링 필요
```

#### 5. FnGuide (유료)
```python
# 장점
- 정제된 데이터
- 추정치, 컨센서스
- 고급 재무비율

# 단점
❌ 유료 ($$$)
```

### 채권 데이터

#### 1. 한국은행 경제통계시스템 (ECOS) - 무료
```python
웹사이트: https://ecos.bok.or.kr

# 수집 가능 데이터
✅ 국고채 수익률 (3년, 5년, 10년, 20년)
✅ 회사채 수익률 (AAA, AA, A)
✅ 금리 통계
✅ Open API 제공 ⭐

# 사용 예제
API_KEY = "YOUR_KEY"
url = f"https://ecos.bok.or.kr/api/StatisticSearch/{API_KEY}/json/kr/1/100/..."
```

#### 2. 금융투자협회 채권정보센터 (무료)
```python
웹사이트: http://www.kofiabond.or.kr

# 수집 가능 데이터
- 채권 시세
- 발행 정보
- 수익률 곡선
```

#### 3. KRX 채권시장 (무료)
```python
웹사이트: http://bond.krx.co.kr

# 수집 가능 데이터
- 상장채권 정보
- 체결 정보
- 수익률 정보
```

### 예금/적금 데이터

#### 1. 금융감독원 금융상품 통합비교공시 (무료)
```python
웹사이트: https://finlife.fss.or.kr

# 수집 가능 데이터
✅ 예금 금리 (은행별, 기간별)
✅ 적금 금리
✅ 우대조건
✅ Open API 제공 ⭐

# API 사용
API_KEY = "YOUR_KEY"
url = f"http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json?auth={API_KEY}&topFinGrpNo=020000"
```

#### 2. 은행연합회 (무료)
```python
웹사이트: https://www.kfb.or.kr

# 수집 가능 데이터
- 은행 금리 비교
- 예금자보호 안내
```

### ETF 데이터

#### 1. KRX ETF (무료)
```python
웹사이트: http://www.krx.co.kr/main/main.jsp

# 수집 가능 데이터
- ETF 기본정보
- NAV, 시장가
- 괴리율
- 보유종목
```

#### 2. ETF Provider (무료)
```python
# 주요 운용사 홈페이지
- 삼성자산운용
- KODEX (삼성)
- TIGER (미래에셋)
- ARIRANG (한화)

# 수집 가능 데이터
- 상세 보유종목
- 섹터 배분
- Fact Sheet
```

---

## 구현 계획

### Step 1: 데이터 수집 스크립트 작성

#### 1.1 주식 핵심 지표 수집

```python
# scripts/collect_stock_fundamentals.py

from pykrx import stock
from datetime import datetime
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.securities import Stock

def update_stock_fundamentals():
    """주식 PER, PBR, 배당률 업데이트"""
    db = SessionLocal()

    try:
        stocks = db.query(Stock).filter(Stock.is_active == True).all()
        today = datetime.now().strftime("%Y%m%d")

        for s in stocks:
            try:
                # pykrx로 데이터 수집
                df = stock.get_market_fundamental(today, today, s.ticker)

                if not df.empty:
                    s.pe_ratio = df['PER'].iloc[0]
                    s.pb_ratio = df['PBR'].iloc[0]
                    s.dividend_yield = df['DIV'].iloc[0]

                    print(f"✅ {s.name}: PER={s.pe_ratio}, PBR={s.pb_ratio}, DIV={s.dividend_yield}")
                else:
                    print(f"⚠️  {s.name}: No data")

            except Exception as e:
                print(f"❌ {s.name}: {e}")
                continue

        db.commit()
        print(f"\n✅ Updated {len(stocks)} stocks")

    finally:
        db.close()

if __name__ == "__main__":
    update_stock_fundamentals()
```

#### 1.2 채권 데이터 수집

```python
# scripts/collect_bond_data.py

import requests
from app.models.securities import Bond

def collect_government_bonds():
    """국고채 수익률 수집 (한국은행 ECOS)"""

    API_KEY = "YOUR_ECOS_API_KEY"

    bonds_to_create = [
        {
            "name": "국고채 3년",
            "bond_type": "government",
            "issuer": "대한민국 정부",
            "maturity_years": 3,
            "credit_rating": "AAA",
            "risk_level": "low",
            "investment_type": "conservative,moderate"
        },
        {
            "name": "국고채 5년",
            "bond_type": "government",
            "issuer": "대한민국 정부",
            "maturity_years": 5,
            "credit_rating": "AAA",
            "risk_level": "low",
            "investment_type": "conservative,moderate"
        },
        {
            "name": "국고채 10년",
            "bond_type": "government",
            "issuer": "대한민국 정부",
            "maturity_years": 10,
            "credit_rating": "AAA",
            "risk_level": "low",
            "investment_type": "conservative,moderate,aggressive"
        }
    ]

    # ECOS API 호출하여 수익률 가져오기
    url = f"https://ecos.bok.or.kr/api/StatisticSearch/{API_KEY}/json/kr/1/100/..."

    # Bond 테이블에 저장
    # ...
```

#### 1.3 예금 데이터 수집

```python
# scripts/collect_deposit_data.py

import requests
from app.models.securities import DepositProduct

def collect_deposits():
    """예금 상품 수집 (금융감독원)"""

    API_KEY = "YOUR_FSS_API_KEY"
    url = f"http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json"

    params = {
        "auth": API_KEY,
        "topFinGrpNo": "020000",  # 은행
        "pageNo": 1
    }

    response = requests.get(url, params=params)
    data = response.json()

    # DepositProduct 테이블에 저장
    # ...
```

### Step 2: 스케줄링

```python
# 매일 오전 9시: 주식 지표 업데이트
# 매주 월요일: 채권 수익률 업데이트
# 매월 1일: 예금 금리 업데이트

# Celery Beat 또는 cron 사용
```

### Step 3: 데이터 검증

```python
# scripts/validate_portfolio_data.py

def validate_data_quality():
    """데이터 품질 검증"""

    # 1. NULL 비율 확인
    null_per = calculate_null_ratio("stocks", "pe_ratio")
    null_pbr = calculate_null_ratio("stocks", "pb_ratio")

    # 2. 이상치 탐지
    # PER < 0 또는 > 1000
    # PBR < 0 또는 > 100

    # 3. 리포트 생성
    print(f"PER NULL: {null_per}%")
    print(f"PBR NULL: {null_pbr}%")
```

---

## 체크리스트

### Phase 1 (긴급) - 2주 내

#### 주식 데이터
- [ ] pykrx 설치 및 테스트
- [ ] PER 수집 스크립트 작성
- [ ] PBR 수집 스크립트 작성
- [ ] 배당수익률 수집
- [ ] YTD 수익률 계산
- [ ] 34개 종목 업데이트
- [ ] NULL 비율 0% 달성

#### 채권 데이터
- [ ] 한국은행 ECOS API Key 발급
- [ ] 국고채 3년 추가 (1개)
- [ ] 국고채 5년 추가 (1개)
- [ ] 국고채 10년 추가 (1개)
- [ ] AAA 회사채 추가 (3개)
- [ ] 총 6개 이상 채권 확보

#### 예금 데이터
- [ ] 금융감독원 API Key 발급
- [ ] KB국민은행 1년 예금 추가
- [ ] 신한은행 1년 예금 추가
- [ ] 하나은행 1년 예금 추가
- [ ] 우리은행 1년 예금 추가
- [ ] NH농협은행 1년 예금 추가
- [ ] CMA 1-2개 추가
- [ ] 총 7개 이상 예금상품 확보

#### 검증
- [ ] 포트폴리오 생성 테스트
- [ ] 점수 계산 정상 작동 확인
- [ ] 모든 투자 성향 테스트
- [ ] 문서 업데이트

### Phase 2 (중요) - 4주 내

- [ ] ROE, ROA 추가
- [ ] 베타 계산
- [ ] ETF 추적오차 수집
- [ ] 채권 10개 이상 확보
- [ ] 예금 15개 이상 확보

### Phase 3 (선택) - 8주 내

- [ ] 샤프 비율 계산
- [ ] RSI, 모멘텀 계산
- [ ] 고급 밸류에이션 지표
- [ ] 퀀트 전략 추가

---

## 참고 자료

### 데이터 소스 문서
- [pykrx 공식 문서](https://github.com/sharebook-kr/pykrx)
- [DART Open API](https://opendart.fss.or.kr/guide/main.do)
- [한국은행 ECOS](https://ecos.bok.or.kr/api/)
- [금융감독원 금융상품 API](http://finlife.fss.or.kr/finlife/main/contents.do?menuNo=700028)

### 금융 지표 설명
- [PER이란?](https://www.investopedia.com/terms/p/price-earningsratio.asp)
- [PBR이란?](https://www.investopedia.com/terms/p/price-to-bookratio.asp)
- [배당수익률](https://www.investopedia.com/terms/d/dividendyield.asp)
- [샤프 비율](https://www.investopedia.com/terms/s/sharperatio.asp)

---

**작성자**: Backend Team
**마지막 업데이트**: 2025-12-29
**다음 리뷰**: Phase 1 완료 후 (2주 후)
