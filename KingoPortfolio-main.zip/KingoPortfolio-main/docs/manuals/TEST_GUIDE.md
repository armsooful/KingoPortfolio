# Claude API 연동 테스트 가이드

## 사전 준비

### 1. Anthropic API 키 발급

1. [Anthropic Console](https://console.anthropic.com/) 접속
2. 계정 생성 또는 로그인
3. **API Keys** 메뉴 클릭
4. **Create Key** 버튼 클릭
5. 생성된 API 키 복사 (예: `sk-ant-...`)

⚠️ **주의**: API 키는 한 번만 표시되므로 안전한 곳에 저장하세요!

---

## 테스트 단계

### Step 1: 환경 변수 설정

#### 방법 1: .env 파일 사용 (권장)

```bash
cd backend
cat > .env << EOF
ANTHROPIC_API_KEY=your-actual-api-key-here
SECRET_KEY=your-secret-key-change-in-production-min-32-chars
DATABASE_URL=sqlite:///./kingo.db
EOF
```

#### 방법 2: 환경변수로 직접 설정

```bash
export ANTHROPIC_API_KEY="your-actual-api-key-here"
```

**확인**:
```bash
# .env 파일 확인
cat backend/.env

# 또는 환경변수 확인
echo $ANTHROPIC_API_KEY
```

---

### Step 2: 백엔드 의존성 설치

```bash
cd backend
pip install -r requirements.txt
```

**예상 출력**:
```
Successfully installed anthropic-0.40.0 ...
```

---

### Step 3: 백엔드 서버 시작

```bash
cd backend
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

**성공 시 출력**:
```
✅ CORS Allowed Origins: [...]
✅ Database URL: sqlite:///./kingo.db...
✅ App Name: KingoPortfolio
✅ App Version: 1.0.0
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

**브라우저에서 확인**:
- http://127.0.0.1:8000/docs (Swagger UI)
- http://127.0.0.1:8000/health (헬스체크)

---

### Step 4: 프론트엔드 서버 시작

**새 터미널 창**에서:

```bash
cd frontend
npm install  # 처음 한 번만
npm run dev
```

**성공 시 출력**:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

브라우저가 자동으로 열리거나 http://localhost:5173 접속

---

### Step 5: 전체 플로우 테스트

#### 5.1 회원가입

1. http://localhost:5173 접속
2. **회원가입** 클릭
3. 정보 입력:
   ```
   이메일: test@example.com
   비밀번호: test1234
   이름: 테스터
   ```
4. **회원가입** 버튼 클릭

#### 5.2 로그인

1. 로그인 페이지로 자동 이동 (또는 **로그인** 클릭)
2. 정보 입력:
   ```
   이메일: test@example.com
   비밀번호: test1234
   ```
3. **로그인** 버튼 클릭

#### 5.3 투자성향 진단 설문

1. **설문 시작** 버튼 클릭
2. 15개 문항에 답변 (1-5점 선택)
   - 예시: 모두 3점으로 선택 → 중도형 예상
3. 월 투자 가능액 입력: `100` (100만원)
4. **제출** 버튼 클릭

⏳ **로딩 시간**: Claude AI 분석으로 인해 5-10초 소요

#### 5.4 결과 확인 ✨

**기본 진단 결과**:
- 🎯 투자성향: 보수형/중도형/적극형
- 📊 진단 점수: X.XX / 10
- 💯 신뢰도: XX%
- 📝 특징 리스트
- 💼 추천 포트폴리오 구성
- 📈 기대 연 수익률

**🤖 AI 분석 섹션** (보라색 그라데이션 박스):
1. **개인화된 투자성향 분석**
   - 사용자의 답변 패턴 기반 분석
   - 강점과 주의할 점

2. **투자 조언**
   - 구체적인 투자 전략
   - 추천 자산 배분
   - 단계별 실행 가이드

3. **⚠️ 위험 주의사항**
   - 투자 리스크
   - 피해야 할 행동
   - 위험 관리 방법

---

## 테스트 시나리오별 결과 확인

### 시나리오 1: 보수형 투자자 (1-3점 위주)

**설문 답변**: 대부분 1-2점 선택

**예상 결과**:
- 투자성향: 보수형 (conservative)
- 점수: 0-3.33
- AI 분석 내용:
  - "안정성을 최우선으로..."
  - "채권, 예적금 위주 추천..."
  - "인플레이션 주의..."

### 시나리오 2: 중도형 투자자 (3점 위주)

**설문 답변**: 대부분 3점 선택

**예상 결과**:
- 투자성향: 중도형 (moderate)
- 점수: 3.34-6.66
- AI 분석 내용:
  - "안정성과 수익성의 균형..."
  - "주식 40%, 채권 30% 추천..."
  - "중장기 관점 유지..."

### 시나리오 3: 적극형 투자자 (4-5점 위주)

**설문 답변**: 대부분 4-5점 선택

**예상 결과**:
- 투자성향: 적극형 (aggressive)
- 점수: 6.67-10
- AI 분석 내용:
  - "높은 수익 추구..."
  - "성장주, 기술주 비중 높임..."
  - "레버리지 상품 주의..."

---

## API 키 없이 테스트

API 키를 설정하지 않아도 기본 기능은 작동합니다:

```bash
# .env 파일에서 ANTHROPIC_API_KEY 제거 또는 비워두기
ANTHROPIC_API_KEY=
```

**결과**:
- ✅ 기본 진단 기능: 정상 작동
- ❌ AI 분석 섹션: 표시되지 않음 (백엔드에서 `ai_analysis: null` 반환)

**백엔드 로그**:
```
Claude AI 분석 실패 (무시됨): ANTHROPIC_API_KEY가 설정되지 않았습니다.
```

---

## 문제 해결 (Troubleshooting)

### 1. "ANTHROPIC_API_KEY가 설정되지 않았습니다"

**원인**: API 키가 환경변수에 없음

**해결**:
```bash
cd backend
echo "ANTHROPIC_API_KEY=sk-ant-your-key" >> .env
```

### 2. "Claude API 호출 실패: API connection error"

**원인**: 인터넷 연결 문제 또는 잘못된 API 키

**해결**:
- 인터넷 연결 확인
- API 키 재확인 (https://console.anthropic.com/)
- Anthropic API 상태 확인 (https://status.anthropic.com/)

### 3. AI 분석이 표시되지 않음

**확인 사항**:
```bash
# 백엔드 로그 확인
# 터미널에서 "Claude AI 분석 실패" 메시지 검색

# API 응답 확인 (브라우저 개발자 도구)
# Network 탭 → diagnosis/submit → Response
# "ai_analysis": null 또는 {...} 확인
```

### 4. CORS 에러

**원인**: 프론트엔드-백엔드 origin 불일치

**해결**:
```bash
# backend/.env에 추가
ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
```

### 5. 포트 충돌

**백엔드 포트 변경**:
```bash
uvicorn app.main:app --reload --port 8001
```

**프론트엔드 포트 변경**:
```bash
npm run dev -- --port 5174
```

---

## API 직접 테스트 (cURL)

### 1. 회원가입

```bash
curl -X POST "http://127.0.0.1:8000/auth/signup" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "test1234",
    "name": "테스터"
  }'
```

### 2. 로그인

```bash
curl -X POST "http://127.0.0.1:8000/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=test@example.com&password=test1234"
```

**응답**에서 `access_token` 복사

### 3. 진단 제출 (Claude AI 분석 포함)

```bash
# TOKEN 변수에 위에서 받은 access_token 설정
TOKEN="eyJhbGciOiJIUzI1NiIs..."

curl -X POST "http://127.0.0.1:8000/diagnosis/submit" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "answers": [
      {"question_id": 1, "answer_value": 3},
      {"question_id": 2, "answer_value": 3},
      {"question_id": 3, "answer_value": 3},
      {"question_id": 4, "answer_value": 3},
      {"question_id": 5, "answer_value": 3}
    ],
    "monthly_investment": 100
  }'
```

**확인**: 응답에서 `"ai_analysis"` 필드 확인

---

## 성능 테스트

### AI 분석 응답 시간 측정

```bash
time curl -X POST "http://127.0.0.1:8000/diagnosis/submit" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"answers": [...], "monthly_investment": 100}'
```

**예상 시간**:
- AI 없음: 0.5-1초
- AI 포함: 3-8초 (Claude API 호출 시간)

---

## 프로덕션 배포 테스트

### Render.com 배포 후

1. 환경변수 설정 확인:
   ```
   Dashboard → Environment → ANTHROPIC_API_KEY
   ```

2. 배포 URL로 테스트:
   ```
   https://your-app.onrender.com/docs
   ```

3. 프론트엔드에서 백엔드 URL 확인:
   ```
   frontend/.env.production
   VITE_API_URL=https://your-backend.onrender.com
   ```

---

## 체크리스트

테스트 완료 확인:

- [ ] API 키 발급 완료
- [ ] .env 파일 생성 및 API 키 설정
- [ ] requirements.txt에 anthropic 패키지 확인
- [ ] 백엔드 서버 정상 실행 (8000 포트)
- [ ] 프론트엔드 서버 정상 실행 (5173 포트)
- [ ] 회원가입 성공
- [ ] 로그인 성공
- [ ] 설문 제출 성공
- [ ] 기본 진단 결과 표시 확인
- [ ] 🤖 AI 분석 섹션 표시 확인
  - [ ] 개인화된 투자성향 분석
  - [ ] 투자 조언
  - [ ] 위험 주의사항
- [ ] AI 분석 내용이 설문 답변과 관련 있는지 확인
- [ ] 다양한 투자성향 시나리오 테스트 (보수/중도/적극)

---

## 다음 단계

테스트 완료 후:

1. ✅ 로컬 환경에서 정상 작동 확인
2. 🚀 프로덕션 배포 (Render.com, Vercel)
3. 📊 사용자 피드백 수집
4. 🔧 성능 최적화 (캐싱, 배치 처리)
5. 💰 비용 모니터링 (Anthropic API 사용량)

---

**문제가 있으면 GitHub Issues에 보고해주세요!**
